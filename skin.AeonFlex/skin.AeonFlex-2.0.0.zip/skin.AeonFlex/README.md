# skin.AeonFlex
Ein Skin für Kodi
Der Skin ist ausschliesslich für Kodi Jarvis+ entwickelt worden und sollte auch nur mit einer Jarvis Version zum Einsatz kommen.

Der AeonFlex läuft auf allen Geräten (ausser solche welche nur via Touchscreen bedient werden können) sofern diese eine Version Kodi Jarvis unterstützen.

Die Musiksektion ist minimalistisch gehalten und wird dann zu einem späteren Zeitpunkt ausgebaut.

***********************************************************************************************************************************************************

The skin has been developed exclusively for Kodi Jarvis and should also come with a Jarvis version used.

The AeonFlex runs on all devices (except those which can only be operated via touchscreen) provided these support a Kodi Jarvis version.

The music section is minimalistic and is then expanded at a later date.